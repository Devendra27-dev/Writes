# Building the Lead CRM Android APK

This guide walks you through generating an installable APK file from this project using Capacitor.

## Prerequisites

Install these on your computer (not on your phone):

1. **Node.js** (v18 or newer) — https://nodejs.org
2. **Android Studio** (includes Android SDK + Gradle) — https://developer.android.com/studio
3. **Java JDK 17** (bundled with Android Studio, or install separately)

Verify installation:
```bash
node -v
npx cap --version
```

## Step 1 — Install Dependencies

```bash
npm install
```

## Step 2 — Build the Web App

```bash
npm run build
```

This compiles the React app into the `dist/` folder, which Capacitor packages into the native app.

## Step 3 — Add the Android Platform (first time only)

```bash
npx cap add android
```

This creates an `android/` folder with the native Android project.

## Step 4 — Copy Web Assets + Apply Native Config

```bash
npx cap sync android
```

This copies your built web app and plugins into the Android project.

## Step 5 — Open in Android Studio

```bash
npx cap open android
```

Android Studio opens. Wait for Gradle sync to finish (bottom status bar).

## Step 6 — Build the APK

### Option A: Debug APK (quick, for testing on your phone)

In Android Studio menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**

Or from the terminal:
```bash
cd android
./gradlew assembleDebug
```

The APK file appears at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### Option B: Release APK (for distribution, signed)

1. Generate a signing key:
```bash
keytool -genkey -v -keystore lead-crm.keystore -alias leadcrm -keyalg RSA -keysize 2048 -validity 10000
```

2. Add signing config to `android/app/build.gradle` (see Android Studio docs), then:
```bash
cd android
./gradlew assembleRelease
```

The release APK appears at:
```
android/app/build/outputs/apk/release/app-release.apk
```

## Step 7 — Install on Your Phone

1. Copy the `.apk` file to your Android phone (USB cable, Google Drive, email, etc.)
2. On your phone, open the APK file
3. If prompted, allow "Install from unknown sources" in Settings
4. Tap **Install**

The **Lead CRM** app icon appears in your app drawer with the teal shield logo.

## One-Command Build (after initial setup)

For subsequent builds, use the shortcut:
```bash
npm run android:build
```

This runs the build, syncs to Android, and runs `gradlew assembleDebug` in one step.

## App Permissions

The app requests these Android permissions (configured automatically):
- **Camera** — to capture property photos
- **Photos / Media** — to select photos from gallery
- **Phone** — to make calls to leads directly
- **Internet** — to sync with Supabase cloud database
- **Storage** — to save and restore backup files

## Troubleshooting

**"gradlew: command not found"**
Use `./gradlew` (with the dot-slash prefix) on Mac/Linux, or `gradlew.bat` on Windows.

**Gradle sync fails in Android Studio**
Make sure Java JDK 17 is installed: `java -version`. In Android Studio, go to File → Project Structure → SDK Location and verify the JDK path.

**App shows a blank white screen**
Run `npm run build` first, then `npx cap sync android` to copy the latest web build into the native project.

**Camera or photos not working**
The app uses standard Android camera intents. Permissions are requested automatically on first use.

## App Details

- **App ID:** `com.leadcrm.app`
- **App Name:** Lead CRM
- **Min Android Version:** Android 7.0 (API 24)
- **Backend:** Supabase (cloud database + image storage)
