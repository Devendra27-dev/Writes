#!/usr/bin/env node
/**
 * Post-Android-setup script.
 * Run AFTER `npx cap add android` to apply Lead CRM customizations:
 *   - App name, package name, permissions
 *   - App icon and splash screen
 *   - Theme colors
 *
 * Usage: node scripts/setup-android.mjs
 */
import { existsSync, copyFileSync, mkdirSync, readFileSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const root = join(__dirname, '..');
const androidDir = join(root, 'android');
const resDir = join(androidDir, 'app/src/main/res');

if (!existsSync(androidDir)) {
  console.error('Error: android/ folder not found. Run "npx cap add android" first.');
  process.exit(1);
}

function ensureDir(p) {
  if (!existsSync(p)) mkdirSync(p, { recursive: true });
}

function copyIcon(src, destDir, name) {
  ensureDir(destDir);
  copyFileSync(join(root, 'resources', src), join(destDir, name));
  console.log(`  Copied ${name} -> ${destDir.replace(root + '/', '')}`);
}

console.log('\n=== Lead CRM Android Setup ===\n');

// 1. Copy app icons to mipmap directories
console.log('Installing app icons...');
const mipmapSizes = [
  { dir: 'mipmap-mdpi', size: 48 },
  { dir: 'mipmap-hdpi', size: 72 },
  { dir: 'mipmap-xhdpi', size: 96 },
  { dir: 'mipmap-xxhdpi', size: 144 },
  { dir: 'mipmap-xxxhdpi', size: 192 },
];

for (const { dir, size } of mipmapSizes) {
  const destDir = join(resDir, dir);
  copyIcon(`icon-${size}.png`, destDir, 'ic_launcher.png');
  copyIcon(`icon-${size}.png`, destDir, 'ic_launcher_round.png');
}

// Also copy to drawable for splash
const drawableDir = join(resDir, 'drawable');
ensureDir(drawableDir);
copyFileSync(join(root, 'resources', 'splash-1024.png'), join(drawableDir, 'splash.png'));
console.log('  Copied splash.png -> drawable/');

// 2. Update strings.xml
console.log('\nUpdating app strings...');
const stringsPath = join(resDir, 'values/strings.xml');
const stringsContent = readFileSync(join(root, 'android-resources/strings.xml'), 'utf-8');
writeFileSync(stringsPath, stringsContent);
console.log('  Updated strings.xml');

// 3. Update styles.xml
console.log('\nUpdating app theme...');
const stylesPath = join(resDir, 'values/styles.xml');
const stylesContent = readFileSync(join(root, 'android-resources/styles.xml'), 'utf-8');
writeFileSync(stylesPath, stylesContent);
console.log('  Updated styles.xml');

// 4. Update AndroidManifest.xml with permissions
console.log('\nUpdating AndroidManifest.xml with permissions...');
const manifestPath = join(androidDir, 'app/src/main/AndroidManifest.xml');
let manifest = readFileSync(manifestPath, 'utf-8');

const permissions = `    <!-- Camera -->
    <uses-permission android:name="android.permission.CAMERA" />
    <!-- Photos / Media -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <!-- Storage for backup/restore -->
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
    <!-- Phone for calling leads -->
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <!-- Internet for Supabase -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />`;

// Insert permissions before <application
if (!manifest.includes('android.permission.CAMERA')) {
  manifest = manifest.replace(/<application/, permissions + '\n    <application');
  writeFileSync(manifestPath, manifest);
  console.log('  Added permissions to AndroidManifest.xml');
} else {
  console.log('  Permissions already present');
}

// 5. Update app label if needed
if (manifest.includes('android:label')) {
  manifest = manifest.replace(/android:label="[^"]*"/, 'android:label="Lead CRM"');
  writeFileSync(manifestPath, manifest);
}

// 6. Set screen orientation to portrait
if (!manifest.includes('android:screenOrientation')) {
  manifest = manifest.replace(/<activity([^>]*)>/, '<activity$1 android:screenOrientation="portrait">');
  writeFileSync(manifestPath, manifest);
  console.log('  Set portrait orientation');
}

console.log('\n=== Setup Complete! ===');
console.log('\nNext steps:');
console.log('  1. Run: npx cap sync android');
console.log('  2. Run: npx cap open android');
console.log('  3. In Android Studio: Build → Build APK(s)');
console.log('  4. APK at: android/app/build/outputs/apk/debug/app-debug.apk');
console.log('');
