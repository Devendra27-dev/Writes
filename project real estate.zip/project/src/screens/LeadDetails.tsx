import { useEffect, useState } from 'react';
import { ArrowLeft, Phone, Edit2, Trash2, Share2, MapPin, Wallet, Home, Users, FileText, Loader2, AlertCircle, User } from 'lucide-react';
import { Lead } from '@/lib/supabase';
import { fetchLead, deleteLead } from '@/lib/api';
import { Avatar } from '@/components/Avatar';
import { StatusBadge } from '@/components/StatusBadge';
import { Modal } from '@/components/Modal';
import { formatDate } from '@/lib/utils';

interface LeadDetailsProps {
  leadId: string;
  onBack: () => void;
  onEdit: () => void;
  onDeleted: () => void;
}

export function LeadDetails({ leadId, onBack, onEdit, onDeleted }: LeadDetailsProps) {
  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [galleryIndex, setGalleryIndex] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchLead(leadId)
      .then((data) => {
        if (active) {
          setLead(data);
          setError(null);
        }
      })
      .catch((e) => active && setError(e instanceof Error ? e.message : 'Failed to load lead'))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [leadId]);

  async function handleDelete() {
    setDeleting(true);
    try {
      await deleteLead(leadId);
      onDeleted();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Delete failed');
      setDeleting(false);
      setShowDeleteConfirm(false);
    }
  }

  function handleCall() {
    if (lead?.phone) window.location.href = `tel:${lead.phone}`;
  }

  async function handleShare() {
    if (!lead) return;
    const text = `Lead: ${lead.full_name}\nPhone: ${lead.phone}\nLocation: ${lead.preferred_location ?? '-'}\nBudget: ${lead.budget ?? '-'}\nRequirement: ${lead.requirement_type}\nStatus: ${lead.lead_status}`;
    if (navigator.share) {
      try { await navigator.share({ title: lead.full_name, text }); } catch { /* user cancelled */ }
    } else {
      await navigator.clipboard.writeText(text);
      alert('Lead details copied to clipboard');
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 size={28} className="animate-spin text-brand-500" />
      </div>
    );
  }

  if (error || !lead) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 px-4">
        <AlertCircle size={32} className="text-rose-500" />
        <p className="text-slate-500">{error ?? 'Lead not found'}</p>
        <button onClick={onBack} className="px-4 py-2 rounded-xl bg-brand-500 text-white text-sm font-medium">Go Back</button>
      </div>
    );
  }

  const photos = lead.photos ?? [];

  return (
    <div className="pb-24 min-h-screen">
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between px-4 py-3">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <ArrowLeft size={22} />
          </button>
          <h1 className="text-lg font-semibold">Lead Details</h1>
          <button onClick={handleShare} className="p-2 -mr-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <Share2 size={20} />
          </button>
        </div>
      </header>

      <div className="px-4 pt-4 space-y-4">
        {/* Profile header */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-card p-5 text-center animate-fade-in">
          <Avatar name={lead.full_name} photoUrl={photos[0]?.url} size={80} />
          <h2 className="text-xl font-bold mt-3">{lead.full_name}</h2>
          <div className="flex items-center justify-center gap-1.5 mt-1 text-sm text-slate-500 dark:text-slate-400">
            <Phone size={14} /> {lead.phone}
          </div>
          <div className="mt-3 flex items-center justify-center gap-2">
            <StatusBadge status={lead.lead_status} size="md" />
            <span className="text-xs px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
              {lead.requirement_type}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2">Added on {formatDate(lead.created_at)}</p>
        </div>

        {/* Quick actions */}
        <div className="grid grid-cols-3 gap-3">
          <ActionButton icon={<Phone size={20} />} label="Call" onClick={handleCall} primary />
          <ActionButton icon={<Edit2 size={20} />} label="Edit" onClick={onEdit} />
          <ActionButton icon={<Trash2 size={20} />} label="Delete" onClick={() => setShowDeleteConfirm(true)} danger />
        </div>

        {/* Info rows */}
        <InfoCard title="Contact Information" icon={<User size={16} />}>
          <InfoRow label="Phone" value={lead.phone} />
          {lead.alt_phone && <InfoRow label="Alt Phone" value={lead.alt_phone} />}
        </InfoCard>

        <InfoCard title="Family Information" icon={<Users size={16} />}>
          <div className="grid grid-cols-2 gap-3">
            <InfoRow label="Members" value={String(lead.family_members)} compact />
            <InfoRow label="Male" value={String(lead.male_members)} compact />
            <InfoRow label="Female" value={String(lead.female_members)} compact />
            <InfoRow label="Bachelors" value={String(lead.bachelors)} compact />
          </div>
        </InfoCard>

        <InfoCard title="Property Details" icon={<Home size={16} />}>
          <InfoRow label="Location" value={lead.preferred_location ?? '-'} icon={<MapPin size={13} />} />
          <InfoRow label="Budget" value={lead.budget ?? '-'} icon={<Wallet size={13} />} />
          <InfoRow label="Property Type" value={lead.property_type ?? '-'} icon={<Home size={13} />} />
          <InfoRow label="Requirement" value={lead.requirement_type} />
        </InfoCard>

        {lead.description && (
          <InfoCard title="Description" icon={<FileText size={16} />}>
            <p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">{lead.description}</p>
          </InfoCard>
        )}

        {/* Photos */}
        {photos.length > 0 && (
          <InfoCard title={`Property Photos (${photos.length})`} icon={<Home size={16} />}>
            <div className="grid grid-cols-3 gap-2">
              {photos.map((photo, i) => (
                <button
                  key={photo.id}
                  onClick={() => setGalleryIndex(i)}
                  className="aspect-square rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 active:scale-95 transition-transform"
                >
                  <img src={photo.url} alt="Property" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </InfoCard>
        )}
      </div>

      {/* Delete confirmation */}
      <Modal open={showDeleteConfirm} onClose={() => setShowDeleteConfirm(false)} title="Delete Lead?">
        <p className="text-sm text-slate-600 dark:text-slate-300 mb-5">
          This will permanently delete <strong>{lead.full_name}</strong> and all attached photos. This cannot be undone.
        </p>
        <div className="flex gap-3">
          <button
            onClick={() => setShowDeleteConfirm(false)}
            className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-medium text-sm"
          >
            Cancel
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {deleting ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
            Delete
          </button>
        </div>
      </Modal>

      {/* Photo gallery modal */}
      <Modal open={galleryIndex !== null} onClose={() => setGalleryIndex(null)}>
        {galleryIndex !== null && photos[galleryIndex] && (
          <div className="animate-scale-in">
            <img src={photos[galleryIndex].url} alt="Property" className="w-full rounded-xl" />
            <div className="flex items-center justify-between mt-3">
              <button
                onClick={() => setGalleryIndex((i) => (i! - 1 + photos.length) % photos.length)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm font-medium"
              >
                Previous
              </button>
              <span className="text-sm text-slate-500">{galleryIndex + 1} / {photos.length}</span>
              <button
                onClick={() => setGalleryIndex((i) => (i! + 1) % photos.length)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm font-medium"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function ActionButton({ icon, label, onClick, primary, danger }: { icon: React.ReactNode; label: string; onClick: () => void; primary?: boolean; danger?: boolean }) {
  const cls = primary
    ? 'bg-brand-50 dark:bg-brand-900/30 text-brand-600 dark:text-brand-300'
    : danger
    ? 'bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-300'
    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300';
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1.5 py-3.5 rounded-2xl ${cls} active:scale-95 transition-transform`}>
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

function InfoCard({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-card p-4 animate-fade-in">
      <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 mb-3">
        {icon}
        <h3 className="font-semibold text-sm uppercase tracking-wide">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function InfoRow({ label, value, icon, compact }: { label: string; value: string; icon?: React.ReactNode; compact?: boolean }) {
  return (
    <div className={compact ? '' : 'flex items-center justify-between py-1.5'}>
      <span className="text-xs text-slate-500 dark:text-slate-400">{label}</span>
      <span className="text-sm font-medium flex items-center gap-1.5">
        {icon}{value}
      </span>
    </div>
  );
}
