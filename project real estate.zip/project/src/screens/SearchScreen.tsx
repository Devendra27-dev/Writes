import { useMemo, useState } from 'react';
import { Lead } from '@/lib/supabase';
import { LeadCard } from '@/components/LeadCard';
import { Search, X, SlidersHorizontal } from 'lucide-react';
import { STATUSES, REQUIREMENT_TYPES, PROPERTY_TYPES } from '@/lib/utils';

interface SearchScreenProps {
  leads: Lead[];
  onLeadClick: (id: string) => void;
}

export function SearchScreen({ leads, onLeadClick }: SearchScreenProps) {
  const [query, setQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [reqFilter, setReqFilter] = useState('');
  const [propFilter, setPropFilter] = useState('');

  const locations = useMemo(() => {
    const set = new Set(leads.map((l) => l.preferred_location).filter(Boolean) as string[]);
    return Array.from(set).sort();
  }, [leads]);

  const filtered = useMemo(() => {
    let result = leads;
    if (query) {
      const q = query.toLowerCase();
      result = result.filter(
        (l) =>
          l.full_name.toLowerCase().includes(q) ||
          l.phone.includes(q) ||
          (l.preferred_location ?? '').toLowerCase().includes(q) ||
          (l.alt_phone ?? '').includes(q)
      );
    }
    if (statusFilter) result = result.filter((l) => l.lead_status === statusFilter);
    if (locationFilter) result = result.filter((l) => l.preferred_location === locationFilter);
    if (reqFilter) result = result.filter((l) => l.requirement_type === reqFilter);
    if (propFilter) result = result.filter((l) => l.property_type === propFilter);
    return result;
  }, [leads, query, statusFilter, locationFilter, reqFilter, propFilter]);

  const hasFilters = statusFilter || locationFilter || reqFilter || propFilter;

  return (
    <div className="pb-24 min-h-screen">
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="px-4 pt-4 pb-3">
          <h1 className="text-2xl font-bold tracking-tight mb-3">Search</h1>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Name, phone, location..."
                className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
              />
              {query && (
                <button onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400">
                  <X size={16} />
                </button>
              )}
            </div>
            <button
              onClick={() => setShowFilters((v) => !v)}
              className={`p-2.5 rounded-xl transition-colors ${showFilters || hasFilters ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
            >
              <SlidersHorizontal size={18} />
            </button>
          </div>

          {showFilters && (
            <div className="mt-3 bg-slate-50 dark:bg-slate-900 rounded-2xl p-3 space-y-3 animate-slide-up">
              {hasFilters && (
                <button
                  onClick={() => { setStatusFilter(''); setLocationFilter(''); setReqFilter(''); setPropFilter(''); }}
                  className="text-xs text-brand-600 dark:text-brand-400 flex items-center gap-1"
                >
                  <X size={12} /> Clear filters
                </button>
              )}
              <FilterRow label="Status">
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Location">
                <select value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {locations.map((l) => <option key={l} value={l}>{l}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Requirement">
                <select value={reqFilter} onChange={(e) => setReqFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {REQUIREMENT_TYPES.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Property">
                <select value={propFilter} onChange={(e) => setPropFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {PROPERTY_TYPES.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </FilterRow>
            </div>
          )}
        </div>
      </header>

      <div className="px-4 pt-4">
        <p className="text-xs text-slate-500 mb-3">{filtered.length} result{filtered.length !== 1 ? 's' : ''}</p>
        <div className="space-y-3">
          {filtered.map((lead) => (
            <LeadCard key={lead.id} lead={lead} onClick={() => onLeadClick(lead.id)} />
          ))}
          {filtered.length === 0 && (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3">
                <Search size={24} className="text-slate-400" />
              </div>
              <p className="text-slate-500 dark:text-slate-400 font-medium">No results</p>
              <p className="text-sm text-slate-400 mt-1">Try a different search or filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-medium text-slate-500 dark:text-slate-400 w-20 shrink-0">{label}</span>
      {children}
    </div>
  );
}
