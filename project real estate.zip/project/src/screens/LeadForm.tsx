import { useState, useEffect } from 'react';
import { ArrowLeft, Save, Loader2, User, Phone, Users, Home, Wallet, FileText, AlertCircle } from 'lucide-react';
import { Lead, LeadFormData, RequirementType, LeadStatus } from '@/lib/supabase';
import { STATUSES, PROPERTY_TYPES, REQUIREMENT_TYPES } from '@/lib/utils';
import { createLead, updateLead } from '@/lib/api';
import { PhotoUpload } from '@/components/PhotoUpload';
import { LeadPhoto } from '@/lib/supabase';

interface LeadFormProps {
  lead?: Lead | null;
  onBack: () => void;
  onSaved: () => void;
}

const emptyForm: LeadFormData = {
  full_name: '',
  phone: '',
  alt_phone: '',
  family_members: 0,
  male_members: 0,
  female_members: 0,
  bachelors: 0,
  preferred_location: '',
  budget: '',
  property_type: '',
  requirement_type: 'Rent',
  lead_status: 'New',
  description: '',
};

export function LeadForm({ lead, onBack, onSaved }: LeadFormProps) {
  const [form, setForm] = useState<LeadFormData>(emptyForm);
  const [photos, setPhotos] = useState<LeadPhoto[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isEdit = !!lead;

  useEffect(() => {
    if (lead) {
      setForm({
        full_name: lead.full_name,
        phone: lead.phone,
        alt_phone: lead.alt_phone ?? '',
        family_members: lead.family_members,
        male_members: lead.male_members,
        female_members: lead.female_members,
        bachelors: lead.bachelors,
        preferred_location: lead.preferred_location ?? '',
        budget: lead.budget ?? '',
        property_type: lead.property_type ?? '',
        requirement_type: lead.requirement_type,
        lead_status: lead.lead_status,
        description: lead.description ?? '',
      });
      setPhotos(lead.photos ?? []);
    }
  }, [lead]);

  function update<K extends keyof LeadFormData>(key: K, value: LeadFormData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.full_name.trim() || !form.phone.trim()) {
      setError('Name and phone number are required.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      if (isEdit && lead) {
        await updateLead(lead.id, form);
      } else {
        const created = await createLead(form);
        // Re-direct to edit mode so photos attach to the new lead
        onSaved();
        return;
      }
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save lead');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="pb-24 min-h-screen">
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <ArrowLeft size={22} />
          </button>
          <h1 className="text-lg font-semibold">{isEdit ? 'Edit Lead' : 'Add New Lead'}</h1>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="px-4 pt-4 space-y-5">
        {error && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 text-sm">
            <AlertCircle size={18} /> {error}
          </div>
        )}

        {/* Basic Info */}
        <Section icon={<User size={16} />} title="Basic Information">
          <Field label="Full Name" required>
            <input
              value={form.full_name}
              onChange={(e) => update('full_name', e.target.value)}
              placeholder="John Doe"
              className="form-input"
            />
          </Field>
          <Field label="Phone Number" required>
            <input
              type="tel"
              value={form.phone}
              onChange={(e) => update('phone', e.target.value)}
              placeholder="+91 98765 43210"
              className="form-input"
            />
          </Field>
          <Field label="Alternate Phone">
            <input
              type="tel"
              value={form.alt_phone ?? ''}
              onChange={(e) => update('alt_phone', e.target.value)}
              placeholder="Optional"
              className="form-input"
            />
          </Field>
        </Section>

        {/* Family Info */}
        <Section icon={<Users size={16} />} title="Family Information">
          <div className="grid grid-cols-2 gap-3">
            <NumberField label="Family Members" value={form.family_members} onChange={(v) => update('family_members', v)} />
            <NumberField label="Male Members" value={form.male_members} onChange={(v) => update('male_members', v)} />
            <NumberField label="Female Members" value={form.female_members} onChange={(v) => update('female_members', v)} />
            <NumberField label="Bachelors" value={form.bachelors} onChange={(v) => update('bachelors', v)} />
          </div>
        </Section>

        {/* Property Details */}
        <Section icon={<Home size={16} />} title="Property Details">
          <Field label="Preferred Location">
            <input
              value={form.preferred_location ?? ''}
              onChange={(e) => update('preferred_location', e.target.value)}
              placeholder="e.g. Bandra West"
              className="form-input"
            />
          </Field>
          <Field label="Budget">
            <input
              value={form.budget ?? ''}
              onChange={(e) => update('budget', e.target.value)}
              placeholder="e.g. 50,000/mo or 1.2 Cr"
              className="form-input"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Property Type">
              <select
                value={form.property_type ?? ''}
                onChange={(e) => update('property_type', e.target.value)}
                className="form-input"
              >
                <option value="">Select</option>
                {PROPERTY_TYPES.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </Field>
            <Field label="Requirement">
              <select
                value={form.requirement_type}
                onChange={(e) => update('requirement_type', e.target.value as RequirementType)}
                className="form-input"
              >
                {REQUIREMENT_TYPES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Lead Status">
            <select
              value={form.lead_status}
              onChange={(e) => update('lead_status', e.target.value as LeadStatus)}
              className="form-input"
            >
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
        </Section>

        {/* Photos */}
        {isEdit && (
          <Section icon={<Wallet size={16} />} title="Property Photos">
            <PhotoUpload leadId={lead!.id} photos={photos} onPhotosChange={setPhotos} />
          </Section>
        )}
        {!isEdit && (
          <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-4 text-sm text-slate-500 dark:text-slate-400">
            You can upload property photos after saving the lead.
          </div>
        )}

        {/* Description */}
        <Section icon={<FileText size={16} />} title="Description / Notes">
          <textarea
            value={form.description ?? ''}
            onChange={(e) => update('description', e.target.value)}
            placeholder="Write detailed information about the customer and their requirements..."
            rows={5}
            className="form-input resize-none"
          />
        </Section>

        {/* Submit */}
        <button
          type="submit"
          disabled={saving}
          className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-semibold shadow-fab active:scale-[0.98] transition-all disabled:opacity-50"
        >
          {saving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
          {saving ? 'Saving...' : isEdit ? 'Update Lead' : 'Save Lead'}
        </button>
      </form>
    </div>
  );
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-card p-4 space-y-3 animate-fade-in">
      <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400">
        {icon}
        <h2 className="font-semibold text-sm uppercase tracking-wide">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
        {label} {required && <span className="text-rose-500">*</span>}
      </label>
      {children}
    </div>
  );
}

function NumberField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">{label}</label>
      <input
        type="number"
        min={0}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value) || 0)}
        className="form-input"
      />
    </div>
  );
}
