import { useMemo, useState } from 'react';
import { Lead } from '@/lib/supabase';
import { LeadCard } from '@/components/LeadCard';
import { Search, SlidersHorizontal, ChevronDown, Plus, Users, Wallet, TrendingUp, X } from 'lucide-react';
import { STATUSES, REQUIREMENT_TYPES, PROPERTY_TYPES } from '@/lib/utils';

interface DashboardProps {
  leads: Lead[];
  onLeadClick: (id: string) => void;
  onAddClick: () => void;
  onSearchClick: () => void;
  loading: boolean;
}

type SortKey = 'recent' | 'name' | 'budget';

export function Dashboard({ leads, onLeadClick, onAddClick, onSearchClick, loading }: DashboardProps) {
  const [query, setQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [locationFilter, setLocationFilter] = useState<string>('');
  const [reqFilter, setReqFilter] = useState<string>('');
  const [propFilter, setPropFilter] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortKey>('recent');

  const locations = useMemo(() => {
    const set = new Set(leads.map((l) => l.preferred_location).filter(Boolean) as string[]);
    return Array.from(set).sort();
  }, [leads]);

  const filtered = useMemo(() => {
    let result = leads;
    if (query) {
      const q = query.toLowerCase();
      result = result.filter(
        (l) =>
          l.full_name.toLowerCase().includes(q) ||
          l.phone.includes(q) ||
          (l.preferred_location ?? '').toLowerCase().includes(q) ||
          (l.alt_phone ?? '').includes(q)
      );
    }
    if (statusFilter) result = result.filter((l) => l.lead_status === statusFilter);
    if (locationFilter) result = result.filter((l) => l.preferred_location === locationFilter);
    if (reqFilter) result = result.filter((l) => l.requirement_type === reqFilter);
    if (propFilter) result = result.filter((l) => l.property_type === propFilter);

    const sorted = [...result];
    if (sortBy === 'name') sorted.sort((a, b) => a.full_name.localeCompare(b.full_name));
    else if (sortBy === 'budget') {
      const parseBudget = (b: string | null) => {
        if (!b) return 0;
        const n = parseFloat(b.replace(/[^0-9.]/g, ''));
        return isNaN(n) ? 0 : n;
      };
      sorted.sort((a, b) => parseBudget(b.budget) - parseBudget(a.budget));
    } else sorted.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

    return sorted;
  }, [leads, query, statusFilter, locationFilter, reqFilter, propFilter, sortBy]);

  const stats = useMemo(() => {
    const total = leads.length;
    const newLeads = leads.filter((l) => l.lead_status === 'New').length;
    const closed = leads.filter((l) => l.lead_status === 'Closed').length;
    return { total, newLeads, closed };
  }, [leads]);

  const hasFilters = statusFilter || locationFilter || reqFilter || propFilter;

  function clearFilters() {
    setStatusFilter('');
    setLocationFilter('');
    setReqFilter('');
    setPropFilter('');
  }

  return (
    <div className="pb-24">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="px-4 pt-4 pb-3">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Lead CRM</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">Real Estate Lead Manager</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-semibold">
              {leads.length}
            </div>
          </div>

          {/* Search bar */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search name, phone, location..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 transition-all"
              />
            </div>
            <button
              onClick={() => setShowFilters((v) => !v)}
              className={`p-2.5 rounded-xl transition-colors ${showFilters || hasFilters ? 'bg-brand-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
            >
              <SlidersHorizontal size={18} />
            </button>
          </div>

          {/* Sort */}
          <div className="flex items-center gap-2 mt-2.5 overflow-x-auto no-scrollbar">
            {(['recent', 'name', 'budget'] as SortKey[]).map((key) => (
              <button
                key={key}
                onClick={() => setSortBy(key)}
                className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                  sortBy === key
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                {key === 'recent' ? 'Recent' : key === 'name' ? 'Name' : 'Budget'}
              </button>
            ))}
          </div>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div className="px-4 pb-3 animate-slide-up">
            <div className="bg-slate-50 dark:bg-slate-900 rounded-2xl p-3 space-y-3">
              {hasFilters && (
                <button onClick={clearFilters} className="text-xs text-brand-600 dark:text-brand-400 flex items-center gap-1">
                  <X size={12} /> Clear all filters
                </button>
              )}
              <FilterRow label="Status">
                <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Location">
                <select value={locationFilter} onChange={(e) => setLocationFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {locations.map((l) => <option key={l} value={l}>{l}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Requirement">
                <select value={reqFilter} onChange={(e) => setReqFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {REQUIREMENT_TYPES.map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              </FilterRow>
              <FilterRow label="Property Type">
                <select value={propFilter} onChange={(e) => setPropFilter(e.target.value)} className="filter-select">
                  <option value="">All</option>
                  {PROPERTY_TYPES.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </FilterRow>
            </div>
          </div>
        )}
      </header>

      {/* Stats */}
      <div className="px-4 pt-4">
        <div className="grid grid-cols-3 gap-3">
          <StatCard icon={<Users size={18} />} label="Total" value={stats.total} color="brand" />
          <StatCard icon={<TrendingUp size={18} />} label="New" value={stats.newLeads} color="blue" />
          <StatCard icon={<Wallet size={18} />} label="Closed" value={stats.closed} color="emerald" />
        </div>
      </div>

      {/* List */}
      <div className="px-4 pt-4 space-y-3">
        {loading && <p className="text-center text-sm text-slate-500 py-8">Loading leads...</p>}
        {!loading && filtered.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3">
              <Search size={24} className="text-slate-400" />
            </div>
            <p className="text-slate-500 dark:text-slate-400 font-medium">No leads found</p>
            <p className="text-sm text-slate-400 mt-1">{hasFilters || query ? 'Try adjusting filters' : 'Tap + to add your first lead'}</p>
          </div>
        )}
        {!loading && filtered.map((lead) => (
          <LeadCard key={lead.id} lead={lead} onClick={() => onLeadClick(lead.id)} />
        ))}
      </div>

      {/* FAB */}
      <button
        onClick={onAddClick}
        className="fixed bottom-20 right-4 z-40 w-14 h-14 rounded-full bg-brand-500 hover:bg-brand-600 text-white shadow-fab flex items-center justify-center active:scale-90 transition-transform"
      >
        <Plus size={26} />
      </button>
    </div>
  );
}

function FilterRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-medium text-slate-500 dark:text-slate-400 w-20 shrink-0">{label}</span>
      {children}
    </div>
  );
}

function StatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: 'brand' | 'blue' | 'emerald' }) {
  const colors = {
    brand: 'bg-brand-50 text-brand-600 dark:bg-brand-900/30 dark:text-brand-300',
    blue: 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300',
    emerald: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-300',
  };
  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-3 shadow-card">
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-1.5 ${colors[color]}`}>{icon}</div>
      <p className="text-xl font-bold">{value}</p>
      <p className="text-[11px] text-slate-500 dark:text-slate-400">{label}</p>
    </div>
  );
}
