import { useRef, useState } from 'react';
import { Moon, Sun, Download, Upload, FileDown, FileUp, Info, Database, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useTheme } from '@/context/ThemeContext';
import { supabase, Lead, LeadPhoto } from '@/lib/supabase';
import { Modal } from '@/components/Modal';

interface SettingsProps {
  onLeadsChanged: () => void;
}

export function Settings({ onLeadsChanged }: SettingsProps) {
  const { theme, toggleTheme } = useTheme();
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showAbout, setShowAbout] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);

  async function exportData() {
    setBusy('export');
    try {
      const { data: leads, error } = await supabase.from('leads').select('*, photos:lead_photos(*)');
      if (error) throw error;
      const blob = new Blob([JSON.stringify(leads ?? [], null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `lead-crm-backup-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setMessage({ type: 'success', text: 'Data exported successfully' });
    } catch (e) {
      setMessage({ type: 'error', text: e instanceof Error ? e.message : 'Export failed' });
    } finally {
      setBusy(null);
    }
  }

  async function importData(file: File) {
    setBusy('import');
    try {
      const text = await file.text();
      const leads = JSON.parse(text) as Lead[];
      if (!Array.isArray(leads)) throw new Error('Invalid backup file');

      for (const lead of leads) {
        const { id, photos, created_at, updated_at, ...rest } = lead;
        const { error } = await supabase.from('leads').upsert({ id, ...rest, created_at, updated_at });
        if (error) throw error;
        if (photos && photos.length > 0) {
          for (const photo of photos) {
            const { id: pid, created_at: pcat, ...prest } = photo as LeadPhoto;
            await supabase.from('lead_photos').upsert({ id: pid, ...prest, created_at: pcat });
          }
        }
      }
      setMessage({ type: 'success', text: `Imported ${leads.length} leads` });
      onLeadsChanged();
    } catch (e) {
      setMessage({ type: 'error', text: e instanceof Error ? e.message : 'Import failed' });
    } finally {
      setBusy(null);
      if (importInputRef.current) importInputRef.current.value = '';
    }
  }

  function flash() {
    setTimeout(() => setMessage(null), 3500);
  }

  return (
    <div className="pb-24 min-h-screen" onClick={flash}>
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur-lg border-b border-slate-100 dark:border-slate-800">
        <div className="px-4 py-4">
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        </div>
      </header>

      <div className="px-4 pt-4 space-y-4">
        {message && (
          <div className={`flex items-center gap-2 p-3 rounded-xl text-sm animate-slide-up ${message.type === 'success' ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-rose-50 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400'}`}>
            {message.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
            {message.text}
          </div>
        )}

        {/* Appearance */}
        <SettingsGroup title="Appearance">
          <SettingsRow
            icon={theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />}
            label="Dark Mode"
            subtitle={theme === 'dark' ? 'On' : 'Off'}
            action={
              <button
                onClick={toggleTheme}
                className={`relative w-12 h-7 rounded-full transition-colors ${theme === 'dark' ? 'bg-brand-500' : 'bg-slate-200'}`}
              >
                <span className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow transition-transform ${theme === 'dark' ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            }
          />
        </SettingsGroup>

        {/* Data Management */}
        <SettingsGroup title="Data Management">
          <SettingsRow
            icon={<Download size={20} />}
            label="Backup Data"
            subtitle="Download all leads as a file"
            onClick={exportData}
            trailing={busy === 'export' ? <Loader2 size={18} className="animate-spin text-brand-500" /> : undefined}
          />
          <SettingsRow
            icon={<Upload size={20} />}
            label="Restore Data"
            subtitle="Import from a backup file"
            onClick={() => importInputRef.current?.click()}
            trailing={busy === 'import' ? <Loader2 size={18} className="animate-spin text-brand-500" /> : undefined}
          />
          <SettingsRow
            icon={<FileDown size={20} />}
            label="Export Data"
            subtitle="Save leads as JSON"
            onClick={exportData}
          />
          <SettingsRow
            icon={<FileUp size={20} />}
            label="Import Data"
            subtitle="Load leads from JSON"
            onClick={() => importInputRef.current?.click()}
          />
          <input
            ref={importInputRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && importData(e.target.files[0])}
          />
        </SettingsGroup>

        {/* About */}
        <SettingsGroup title="About">
          <SettingsRow
            icon={<Info size={20} />}
            label="About Lead CRM"
            subtitle="Version 1.0.0"
            onClick={() => setShowAbout(true)}
          />
          <SettingsRow
            icon={<Database size={20} />}
            label="Storage"
            subtitle="Supabase cloud backend"
          />
        </SettingsGroup>

        <p className="text-center text-xs text-slate-400 pt-2">Lead CRM v1.0.0 - Built for real estate professionals</p>
      </div>

      <Modal open={showAbout} onClose={() => setShowAbout(false)} title="About Lead CRM">
        <div className="space-y-3 text-sm text-slate-600 dark:text-slate-300">
          <div className="flex justify-center mb-2">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center">
              <Database size={32} className="text-white" />
            </div>
          </div>
          <p className="text-center font-semibold text-base">Lead CRM</p>
          <p className="text-center text-xs text-slate-400">Version 1.0.0</p>
          <p>
            A professional lead management application for real estate agents. Replace your Excel sheets with a fast,
            organized, and beautiful CRM that keeps all your client information and property photos in one place.
          </p>
          <p className="text-xs text-slate-400">Data is stored securely in the cloud via Supabase. All photos remain permanently attached to their leads.</p>
        </div>
      </Modal>
    </div>
  );
}

function SettingsGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 px-2 mb-2">{title}</h2>
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-card overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
        {children}
      </div>
    </div>
  );
}

function SettingsRow({ icon, label, subtitle, onClick, action, trailing }: { icon: React.ReactNode; label: string; subtitle?: string; onClick?: () => void; action?: React.ReactNode; trailing?: React.ReactNode }) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3.5 ${onClick ? 'cursor-pointer active:bg-slate-50 dark:active:bg-slate-800' : ''} transition-colors`}
    >
      <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium">{label}</p>
        {subtitle && <p className="text-xs text-slate-500 dark:text-slate-400">{subtitle}</p>}
      </div>
      {action ?? trailing}
    </div>
  );
}
