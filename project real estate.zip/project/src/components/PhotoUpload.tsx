import { useRef, useState } from 'react';
import { Camera, X, ImagePlus, Loader2 } from 'lucide-react';
import { uploadPhoto, deletePhoto } from '@/lib/api';
import { LeadPhoto } from '@/lib/supabase';

interface PhotoUploadProps {
  leadId: string;
  photos: LeadPhoto[];
  onPhotosChange: (photos: LeadPhoto[]) => void;
}

export function PhotoUpload({ leadId, photos, onPhotosChange }: PhotoUploadProps) {
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(true);
    setError(null);
    try {
      const newPhotos: LeadPhoto[] = [];
      for (const file of Array.from(files)) {
        const photo = await uploadPhoto(leadId, file);
        newPhotos.push(photo);
      }
      onPhotosChange([...photos, ...newPhotos]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Upload failed');
    } finally {
      setUploading(false);
      if (cameraInputRef.current) cameraInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    }
  }

  async function handleDelete(photo: LeadPhoto) {
    try {
      await deletePhoto(photo);
      onPhotosChange(photos.filter((p) => p.id !== photo.id));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    }
  }

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <button
          type="button"
          onClick={() => cameraInputRef.current?.click()}
          disabled={uploading}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 font-medium text-sm hover:bg-brand-100 dark:hover:bg-brand-900/50 transition-colors disabled:opacity-50"
        >
          <Camera size={18} /> Camera
        </button>
        <button
          type="button"
          onClick={() => galleryInputRef.current?.click()}
          disabled={uploading}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-sm hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors disabled:opacity-50"
        >
          <ImagePlus size={18} /> Gallery
        </button>
      </div>

      <input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />

      {uploading && (
        <div className="flex items-center justify-center gap-2 py-3 text-sm text-slate-500 dark:text-slate-400">
          <Loader2 size={16} className="animate-spin" /> Uploading...
        </div>
      )}

      {error && <p className="text-sm text-rose-500 mb-2">{error}</p>}

      {photos.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {photos.map((photo) => (
            <div key={photo.id} className="relative group aspect-square rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800">
              <img src={photo.url} alt="Property" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => handleDelete(photo)}
                className="absolute top-1 right-1 p-1 rounded-full bg-black/60 text-white opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
