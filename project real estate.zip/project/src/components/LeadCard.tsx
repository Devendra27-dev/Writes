import { Lead } from '@/lib/supabase';
import { Avatar } from './Avatar';
import { StatusBadge } from './StatusBadge';
import { MapPin, Phone, Wallet, Home, Users, ChevronRight } from 'lucide-react';

interface LeadCardProps {
  lead: Lead;
  onClick: () => void;
}

export function LeadCard({ lead, onClick }: LeadCardProps) {
  const firstPhoto = lead.photos?.[0]?.url;

  return (
    <button
      onClick={onClick}
      className="w-full text-left bg-white dark:bg-slate-900 rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-200 p-4 active:scale-[0.98] animate-fade-in"
    >
      <div className="flex items-start gap-3">
        <Avatar name={lead.full_name} photoUrl={firstPhoto} size={52} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 truncate">{lead.full_name}</h3>
            <ChevronRight size={18} className="text-slate-300 dark:text-slate-600 shrink-0" />
          </div>
          <div className="flex items-center gap-1.5 mt-0.5 text-sm text-slate-500 dark:text-slate-400">
            <Phone size={13} />
            <span className="truncate">{lead.phone}</span>
          </div>
          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2 text-xs text-slate-500 dark:text-slate-400">
            {lead.preferred_location && (
              <span className="inline-flex items-center gap-1">
                <MapPin size={12} /> {lead.preferred_location}
              </span>
            )}
            {lead.budget && (
              <span className="inline-flex items-center gap-1">
                <Wallet size={12} /> {lead.budget}
              </span>
            )}
            {lead.property_type && (
              <span className="inline-flex items-center gap-1">
                <Home size={12} /> {lead.property_type}
              </span>
            )}
            {lead.family_members > 0 && (
              <span className="inline-flex items-center gap-1">
                <Users size={12} /> {lead.family_members}
              </span>
            )}
          </div>
          <div className="mt-2.5 flex items-center justify-between">
            <StatusBadge status={lead.lead_status} />
            <span className="text-[11px] text-slate-400 dark:text-slate-500">
              {lead.requirement_type}
            </span>
          </div>
        </div>
      </div>
    </button>
  );
}
