import { LeadStatus } from '@/lib/supabase';
import { STATUS_CONFIG } from '@/lib/utils';

export function StatusBadge({ status, size = 'sm' }: { status: LeadStatus; size?: 'sm' | 'md' }) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.New;
  const padding = size === 'md' ? 'px-3 py-1 text-xs' : 'px-2 py-0.5 text-[11px]';
  return (
    <span className={`inline-flex items-center rounded-full border font-medium ${cfg.bg} ${cfg.text} ${cfg.border} ${padding}`}>
      {cfg.label}
    </span>
  );
}
