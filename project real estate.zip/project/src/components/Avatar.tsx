import { getInitials } from '@/lib/utils';

const AVATAR_COLORS = [
  'from-teal-400 to-teal-600',
  'from-blue-400 to-blue-600',
  'from-rose-400 to-rose-600',
  'from-amber-400 to-amber-600',
  'from-violet-400 to-violet-600',
  'from-emerald-400 to-emerald-600',
  'from-cyan-400 to-cyan-600',
  'from-orange-400 to-orange-600',
];

function pickColor(name: string) {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}

export function Avatar({ name, photoUrl, size = 48 }: { name: string; photoUrl?: string | null; size?: number }) {
  if (photoUrl) {
    return (
      <img
        src={photoUrl}
        alt={name}
        style={{ width: size, height: size }}
        className="rounded-full object-cover ring-2 ring-white dark:ring-slate-800"
      />
    );
  }
  return (
    <div
      style={{ width: size, height: size, fontSize: size * 0.36 }}
      className={`rounded-full bg-gradient-to-br ${pickColor(name)} flex items-center justify-center font-semibold text-white ring-2 ring-white dark:ring-slate-800 shrink-0`}
    >
      {getInitials(name) || '?'}
    </div>
  );
}
