import { useEffect, useState, useCallback } from 'react';
import { ThemeProvider } from '@/context/ThemeContext';
import { BottomNav, Tab } from '@/components/BottomNav';
import { Dashboard } from '@/screens/Dashboard';
import { LeadForm } from '@/screens/LeadForm';
import { LeadDetails } from '@/screens/LeadDetails';
import { SearchScreen } from '@/screens/SearchScreen';
import { Settings } from '@/screens/Settings';
import { Lead } from '@/lib/supabase';
import { fetchLeads } from '@/lib/api';

type View =
  | { name: 'tab'; tab: Tab }
  | { name: 'leadDetails'; leadId: string; from: Tab }
  | { name: 'leadForm'; leadId?: string; from: Tab };

function AppInner() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<View>({ name: 'tab', tab: 'dashboard' });

  const loadLeads = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchLeads();
      setLeads(data);
    } catch (e) {
      console.error('Failed to load leads', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadLeads();
  }, [loadLeads]);

  const currentTab: Tab = view.name === 'tab' ? view.tab : view.from;

  function handleTabChange(tab: Tab) {
    setView({ name: 'tab', tab });
  }

  function openLeadDetails(id: string) {
    setView({ name: 'leadDetails', leadId: id, from: currentTab });
  }

  function openLeadForm(id?: string) {
    setView({ name: 'leadForm', leadId: id, from: currentTab });
  }

  function backToTab() {
    setView({ name: 'tab', tab: currentTab });
  }

  return (
    <div className="max-w-md mx-auto min-h-screen bg-slate-50 dark:bg-slate-950">
      {view.name === 'tab' && view.tab === 'dashboard' && (
        <Dashboard
          leads={leads}
          onLeadClick={openLeadDetails}
          onAddClick={() => openLeadForm()}
          onSearchClick={() => handleTabChange('search')}
          loading={loading}
        />
      )}

      {view.name === 'tab' && view.tab === 'add' && (
        <LeadForm onBack={backToTab} onSaved={() => { loadLeads(); backToTab(); }} />
      )}

      {view.name === 'tab' && view.tab === 'search' && (
        <SearchScreen leads={leads} onLeadClick={openLeadDetails} />
      )}

      {view.name === 'tab' && view.tab === 'settings' && (
        <Settings onLeadsChanged={loadLeads} />
      )}

      {view.name === 'leadDetails' && (
        <LeadDetails
          leadId={view.leadId}
          onBack={backToTab}
          onEdit={() => openLeadForm(view.leadId)}
          onDeleted={() => { loadLeads(); backToTab(); }}
        />
      )}

      {view.name === 'leadForm' && (
        <LeadForm
          lead={leads.find((l) => l.id === view.leadId) ?? null}
          onBack={backToTab}
          onSaved={() => { loadLeads(); backToTab(); }}
        />
      )}

      <BottomNav active={currentTab} onChange={handleTabChange} />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}
