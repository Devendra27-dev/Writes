import { LeadStatus } from './supabase';

export const STATUS_CONFIG: Record<LeadStatus, { label: string; bg: string; text: string; border: string }> = {
  New: { label: 'New', bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200' },
  Contacted: { label: 'Contacted', bg: 'bg-violet-50', text: 'text-violet-600', border: 'border-violet-200' },
  'Site Visit': { label: 'Site Visit', bg: 'bg-teal-50', text: 'text-teal-600', border: 'border-teal-200' },
  Negotiation: { label: 'Negotiation', bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-200' },
  Closed: { label: 'Closed', bg: 'bg-rose-50', text: 'text-rose-600', border: 'border-rose-200' },
};

export const STATUSES: LeadStatus[] = ['New', 'Contacted', 'Site Visit', 'Negotiation', 'Closed'];
export const PROPERTY_TYPES = ['1RK', '1BHK', '2BHK', '3BHK', '4BHK', 'Villa', 'Plot', 'Shop', 'Office', 'Other'];
export const REQUIREMENT_TYPES = ['Buy', 'Rent'];

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
