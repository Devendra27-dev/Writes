import { supabase, Lead, LeadFormData, LeadPhoto } from './supabase';

export async function fetchLeads(): Promise<Lead[]> {
  const { data, error } = await supabase
    .from('leads')
    .select('*, photos:lead_photos(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Lead[];
}

export async function fetchLead(id: string): Promise<Lead | null> {
  const { data, error } = await supabase
    .from('leads')
    .select('*, photos:lead_photos(*)')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Lead | null;
}

export async function createLead(form: LeadFormData): Promise<Lead> {
  const { data, error } = await supabase
    .from('leads')
    .insert(form)
    .select()
    .single();
  if (error) throw error;
  return data as Lead;
}

export async function updateLead(id: string, form: Partial<LeadFormData>): Promise<Lead> {
  const { data, error } = await supabase
    .from('leads')
    .update(form)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as Lead;
}

export async function deleteLead(id: string): Promise<void> {
  const { data: photos } = await supabase
    .from('lead_photos')
    .select('storage_path')
    .eq('lead_id', id);

  if (photos && photos.length > 0) {
    const paths = photos.map((p: { storage_path: string }) => p.storage_path);
    await supabase.storage.from('lead-photos').remove(paths);
  }

  const { error } = await supabase.from('leads').delete().eq('id', id);
  if (error) throw error;
}

export async function uploadPhoto(leadId: string, file: File): Promise<LeadPhoto> {
  const ext = file.name.split('.').pop() ?? 'jpg';
  const path = `${leadId}/${Date.now()}.${ext}`;

  const { error: uploadError } = await supabase.storage
    .from('lead-photos')
    .upload(path, file, { upsert: false });
  if (uploadError) throw uploadError;

  const { data: urlData } = supabase.storage
    .from('lead-photos')
    .getPublicUrl(path);

  const { data, error } = await supabase
    .from('lead_photos')
    .insert({ lead_id: leadId, storage_path: path, url: urlData.publicUrl })
    .select()
    .single();
  if (error) throw error;
  return data as LeadPhoto;
}

export async function deletePhoto(photo: LeadPhoto): Promise<void> {
  await supabase.storage.from('lead-photos').remove([photo.storage_path]);
  const { error } = await supabase.from('lead_photos').delete().eq('id', photo.id);
  if (error) throw error;
}
