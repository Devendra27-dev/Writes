import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type LeadStatus = 'New' | 'Contacted' | 'Site Visit' | 'Negotiation' | 'Closed';
export type RequirementType = 'Buy' | 'Rent';

export interface Lead {
  id: string;
  full_name: string;
  phone: string;
  alt_phone: string | null;
  family_members: number;
  male_members: number;
  female_members: number;
  bachelors: number;
  preferred_location: string | null;
  budget: string | null;
  property_type: string | null;
  requirement_type: RequirementType;
  lead_status: LeadStatus;
  description: string | null;
  created_at: string;
  updated_at: string;
  photos?: LeadPhoto[];
}

export interface LeadPhoto {
  id: string;
  lead_id: string;
  storage_path: string;
  url: string;
  created_at: string;
}

export type LeadFormData = Omit<Lead, 'id' | 'created_at' | 'updated_at' | 'photos'>;
