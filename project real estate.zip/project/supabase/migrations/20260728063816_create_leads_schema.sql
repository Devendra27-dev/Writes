/*
# Lead CRM Schema

## Overview
Creates the full schema for a real estate lead management app (single-tenant, no auth).

## New Tables

### `leads`
Stores all client lead information including contact details, family info, property requirements, and status.

Columns:
- `id` – UUID primary key
- `full_name` – client's full name
- `phone` – primary phone number
- `alt_phone` – optional alternate phone
- `family_members` – total family member count
- `male_members` – number of male members
- `female_members` – number of female members
- `bachelors` – number of bachelors
- `preferred_location` – desired property location
- `budget` – budget as text (supports ranges like "4k/mo" or "50 lac")
- `property_type` – e.g. 1RK, 1BHK, 2BHK
- `requirement_type` – Buy or Rent
- `lead_status` – New / Contacted / Site Visit / Negotiation / Closed
- `description` – free-form notes
- `created_at`, `updated_at` – timestamps

### `lead_photos`
Stores references to photos attached to a lead (URLs from Supabase Storage).

Columns:
- `id` – UUID primary key
- `lead_id` – foreign key to leads
- `storage_path` – path in the Supabase storage bucket
- `url` – public URL of the photo
- `created_at` – timestamp

## Security
- RLS enabled on both tables with open anon + authenticated CRUD (single-tenant personal app).

## Notes
- No auth required — personal single-user tool.
- Indexes on lead status, location, requirement_type for fast filtering.
*/

-- Leads table
CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  phone text NOT NULL,
  alt_phone text,
  family_members integer DEFAULT 0,
  male_members integer DEFAULT 0,
  female_members integer DEFAULT 0,
  bachelors integer DEFAULT 0,
  preferred_location text,
  budget text,
  property_type text,
  requirement_type text DEFAULT 'Rent',
  lead_status text DEFAULT 'New',
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_leads" ON leads;
CREATE POLICY "anon_select_leads" ON leads FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads" ON leads FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_leads" ON leads;
CREATE POLICY "anon_update_leads" ON leads FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_leads" ON leads;
CREATE POLICY "anon_delete_leads" ON leads FOR DELETE TO anon, authenticated USING (true);

-- Lead photos table
CREATE TABLE IF NOT EXISTS lead_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE lead_photos ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_lead_photos" ON lead_photos;
CREATE POLICY "anon_select_lead_photos" ON lead_photos FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_lead_photos" ON lead_photos;
CREATE POLICY "anon_insert_lead_photos" ON lead_photos FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_lead_photos" ON lead_photos;
CREATE POLICY "anon_update_lead_photos" ON lead_photos FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_lead_photos" ON lead_photos;
CREATE POLICY "anon_delete_lead_photos" ON lead_photos FOR DELETE TO anon, authenticated USING (true);

-- Indexes for common filter/search operations
CREATE INDEX IF NOT EXISTS idx_leads_lead_status ON leads(lead_status);
CREATE INDEX IF NOT EXISTS idx_leads_preferred_location ON leads(preferred_location);
CREATE INDEX IF NOT EXISTS idx_leads_requirement_type ON leads(requirement_type);
CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_photos_lead_id ON lead_photos(lead_id);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_leads_updated_at ON leads;
CREATE TRIGGER set_leads_updated_at
  BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
